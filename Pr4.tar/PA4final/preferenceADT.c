
/*
 *  Author:Zheng Zhong, Zhengz42@uw,edu
 *  Version: 1.0
 *  Enviorment:Ubuntu 16.04 LTS Desktop 32-bit
 *  Option: Option 2
 *  Data: 3/4/2021
 *
 *  Defines preference Abstract Data Type
 *  
 *
 */ 

#include "preferenceADT.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define SIZE 128

//struct preference
struct preference_type{

	int id;
	int bedroom;
	int bathroom;
	int price;
	int neightborhoodid;

};


//PreferenceADT constructor
//pre:client id:id,bedroom:bed,bathroom:bath,price:price,and neighthoodid
//pos:a preferenceADT is created
Preference createPreference(/*in*/ int id,
                            /*in*/ int bed,
                            /*in*/ int bath,
                            /*in*/ int price,
                            /*in*/ int neighthoodid)

{

	Preference temp = malloc(sizeof(struct preference_type));
        if (temp != NULL) {

  		temp->id = id;
		temp->bedroom = bed;
		temp->bathroom = bath;
 	        temp->price = price;
  		temp->neightborhoodid = neighthoodid;
       }
        
        return temp;



}

//prints preference info
//pre: preferenceType:pre
//pos: displayed the preference info
void printPreference(/*in*/ Preference pre){

	printf("Preference: id:%d,min bed:%d,min bath:%d,max price:%d,neightId:%d\n",
		pre->id,
		pre->bedroom,
		pre->bathroom,
		pre->price,
		pre->neightborhoodid);


}

//destroys the preference type
//pre: preferenceType:pre
//pos: the preference type would be destroyed
void destroyPreference(/*inout*/ Preference pre){

	free(pre);
}

//Client preference id getter
//pre: preferenceType:pre
//pos: returned client id stored in the preference
int getPreId(/*in*/ Preference pre){

	return pre->id;

}

//Client preference minimum number of bedroom getter
//pre: preferenceType:pre
//pos: returned minimum number of bedrom
int getMinBed(/*in*/ Preference pre){

	return pre->bedroom;

}

//Client preference minimum number of bathroom getter
//pre: preferenceType:pre
//pos: returned minimum number of bathrom

int getMinBath(/*in*/ Preference pre){
	
	return pre->bathroom;
}

//Client preference maximum price getter
//pre: preferenceType:pre
//pos: returned maximum price
int getMaxPrice(/*in*/ Preference pre){

	return pre->price;

}

//Client preference neighthoodid getter
//pre: preferenceType:pre
//pos: returned neighthoodid
int getNeightId(/*in*/ Preference pre){
return pre->neightborhoodid;

}


