/*
 *  Author:Zheng Zhong, Zhengz42@uw,edu
 *  Version: 1.0
 *  Enviorment:Ubuntu 16.04 LTS Desktop 32-bit
 *  Option: Option 2
 *  Data: 3/4/2021
 *
 *  PreferenceADT header file
 *  
 *
 */ 

#ifndef PREFERENCEADT_H
#define PREFERENCEADT_H

/*Struct preference_type alias*/
typedef struct preference_type *Preference;

/*Creates preference type*/
Preference createPreference(int id,
			    int bed,
			    int bath,
			    int price,
			    int neighthoodid);

/*Destroy preference_type*/
void destroyPreference(Preference pre);

/*printpreference information*/
void printPreference(Preference pre);

/*getter of  clientId within the preference type*/
int getPreId(Preference pre);

/*mimimum bedroom number getter*/
int getMinBed(Preference pre);

/*mimimum bathroom number getter*/
int getMinBath(Preference pre);

/*Maximum price getter*/
int getMaxPrice(Preference pre);

/*neightborhood id getter*/
int getNeightId(Preference pre);

#endif
