/*
 *  Author:Zheng Zhong, Zhengz42@uw,edu
 *  Version: 1.0
 *  Enviorment:Ubuntu 16.04 LTS Desktop 32-bit
 *  Option: Option 2
 *  Data: 3/4/2021
 *
 *  This program reads client and reference files ,then matches the houses in the house file
 *  Client file format : client.txt
 *  Prefernce file format:preference.txt
 *  House file format: houses.txt
 *  Result file format : result.csv
 *
 */ 


#include <stdio.h>
#include<stdlib.h>
#include "clientADT.h"
#include "preferenceADT.h"
#include <string.h>

#define MAXSIZE 256

/*Function reads the client file and puts data into the ClientType array*/
void createClientArray       (ClientType   *list,
                              int          *listSize,
                              FILE         *stream);

/*Function sorts the ClientType array*/
void sortClientArray         (ClientType   *list,
  
                            int             listSize);
/*Function reads the preference file and updates the reference data for each client*/
void updatedClientReference  (ClientType   *list ,
                              int          listSize,
                              FILE         *stream);

/*Function reads the house files and outputs matched houses to the result file*/
void findMatch               (ClientType   *list,
                              int          listSize,
                              FILE         *houseFile,
                              FILE         *resultFile);

//Main Function
int main()
{
   
   //IO files set up
   int size,i;
   FILE *clientFile = fopen("clients.txt","r");
   FILE *referenceFile = fopen("preferences.txt","r");
   FILE *houseFile = fopen("houses.txt","r");
   FILE *resultFile = fopen("result.csv","w+");
  
   if (clientFile == NULL){
		puts("could not found the client.txt file");
                exit(0);
   }
   else if (referenceFile == NULL) {
		puts("could not found the preference.txt file");
                exit(0);
   }
   else if (houseFile == NULL) {
                puts("could not found the houses.txt file");
                exit(0);
   } else {
   //Allocates space for ClientType array
   ClientType *ls = calloc(20,sizeof(ClientType));
   size = 0;
 
   createClientArray(ls,&size,clientFile);
   sortClientArray(ls,size);
   updatedClientReference(ls,size,referenceFile);
   findMatch(ls,size,houseFile,resultFile);

  //Free the allocated space
   for (i = 0; i < size ; i++) {
          
          destroyClient(ls[i]);
   }
   free(ls);
   
  //Close IO Files
   fclose(clientFile);
   fclose(referenceFile);
   fclose(houseFile);
   fclose(resultFile);
    }
   return 0;
}

//Reads the input file and adds the ClientType to the array
//pre:ClientType array:list, listSize points to the size location, and input File stream
//post: ClientType array filled with the ClientType data
void createClientArray(/*inout*/ ClientType   *list, 
                       /*inout*/ int          *listSize, 
                       /*in*/    FILE         *stream)
{

    int id,i=0,count=0;
    char name[MAXSIZE] ,email[MAXSIZE],phoneNum[MAXSIZE],line[MAXSIZE];
    //Reads every four lines then creates a ClientType data
    while(fgets(line,MAXSIZE,stream)!=NULL){
                //Reads the first line, stores the client ID 
                if (count == 0) {
                          count+=1;
                          id = atoi(line);
                }
                //Reads the second line,stores the client's name
                else if (count == 1) {
                               memset(name,0,128);
                               count+=1;
                               strcpy(name,line);
                }
                //Read the third line, stores the client's email address
                else if (count == 2) {
                               memset(email,0,128);
                               count+=1;
                               strcpy(email,line);
                }
               //Read the fourth line, stores the phone number, then creates a ClientType and puts into the array
               else if (count == 3) {
                              memset(phoneNum,0,128);
                              strcpy(phoneNum,line);
                              list[i] = createClient(id,name,email,phoneNum);
                              (*listSize)++;
                              i++;
                             //Restores the counter
                              count=0;
               }
     }
}

//Sorts the ClientType array base on the client IDs 
//pre:ClientType array:list, and array size:listSize
//post: A sorted ClientType array
void sortClientArray( /*inout*/  ClientType   *list,
                      /*in*/     int           listSize)
{

   int i,j,left,right;
   ClientType temp;
   //Performs selection sort
   for (i = 0; i < listSize; i++) {
         for (j = i+1; j < listSize; j++){
  
                 left = getClientId(list[i]);
                 right = getClientId(list[j]);
            
                 if (left>right) {
            
                         temp = list[j];
                         list[j]=list[i];
                         list[i] = temp; 
                 }
         }  
   }
}

//Updates the preferences from the preference file 
//pre:ClientType array:list,array size:listSize and File stream:stream
//post:client preferences updated
void updatedClientReference(/*inout*/  ClientType *list ,
                            /*in*/     int        size ,
                            /*in*/     FILE       *stream)
{

      int refid,cliId,count,idx,found,i,bed,bath,price,neid;
      char line[MAXSIZE];
      count=0;
      idx=0;
      //Read the every two lines of the file
      while (fgets(line,MAXSIZE,stream) != NULL) {
             //read the first line,get the client id            
             if (count == 0) {
                       
                       count=+1;
                       refid = atoi(line);
                       found =0;
                       //search the ClientType array, verify the client id and get the index
                       for ( i=0; i<size; i++) {

                            cliId = getClientId(list[i]);
                            
                            if (cliId == refid) {
                                 
                                     idx = i;
                                     found =1;
                                     break;
                             }
                       }
             }
             //Read the second line and updates the preference
             else if (count == 1) {
                            //reset the counter
                            count=0;
                            //if the client is existed,updates preferences to it
                            if (found == 1) {
                                      
                                      sscanf(line,"%d %d %d %d",&bed,&bath,&price,&neid);
                                      updatePreference(list[idx],refid,bed,bath,price,neid);
                             }
              }
      }
}

//Matches the houses based on client preferences and outputs result.
//pre:ClientType array:list,array size:listSize , File stream:houseFile,File stream:resultFile
//post:A txt file contained the house information and client information
void findMatch(/*inout*/ ClientType  *list,
               /*in*/    int         listSize,
               /*in*/    FILE        *houseFile,
               /*out*/   FILE        *resultFile)
{

      int houseBed,houseBath,housePrice,houseNeid,firstLine,repeat,section,idx,i,len;
      char line1[MAXSIZE],line2[MAXSIZE],repStr[MAXSIZE],*token,str[8];
      const char comma[2] = ",",twoComma[MAXSIZE]=",,";
    
      firstLine = 1;
      section = 8;
      //read the house file
      while (fgets(line1,MAXSIZE,houseFile)) {
            //scans the header line from the house file and updates the header
              if (firstLine == 1) {

                           firstLine =0;
                           len = strlen(line1);
                           memmove(&line1[len-2],twoComma,strlen(twoComma));
                           strcat(line1,"Client ID,Name\n");
                           fprintf(resultFile,"%s",line1);
                 //Scans the non-header line
               } else {
                         idx=0;
                         memset(line2,0,128);
                         strcpy(line2,line1);
                         token  = strtok(line1,comma);
                         //Split the string from comma
                         while (token != NULL) {
                        
                                      token  = strtok(NULL,comma);
                                      idx++;
                                      //The fourth substring is the bedroom number, stores it to the bed var
                                      if (idx == (section/2)) {
                          
                                              houseBed = atoi(token);
                                                
                                      }
                                      //The fifth substring is the bathroom number, stores it to the bath var
                                      else if (idx == (section/2)+1) {

                                                   houseBath = atoi(token);
                                      }
                                      //The sixth substring is the price number, stores it to the price var
                                     else if (idx == (section/2)+2) {

                                                  housePrice = atoi(token);
                                                 
                                      }
                                     //The seventh substring is the neighthood number,stores it the neid var
                                     else if (idx == section-1) {

                                                  houseNeid = atoi(token);
                         
                                      }
                         
                         }

                         repeat = 0;
                         //search every client in the array for one house information
                         for ( i = 0; i < listSize; i++) {
                             //the conditions for matching the results
                              if(houseBed >= getMinBed(getPre(list[i])) &&
                                 houseBath >= getMinBath(getPre(list[i])) &&
                                 housePrice <= getMaxPrice(getPre(list[i])) &&
                                 houseNeid <= getNeightId(getPre(list[i]))+10 &&
                                 houseNeid >= getNeightId(getPre(list[i]))-10) {
                                         //if the there is a match, then outputs the house info with client info
                                         if(repeat==0){
                                                  
                                                  len = strlen(line2);
                                                  memmove(&line2[len-2],twoComma,strlen(twoComma));
                                                  sprintf(str,"%d",getClientId(list[i]));
  
                                                  strcat(line2,str);
                                                  strcat(line2,",");
                                                  strcat(line2,getName(list[i]));
                                                  
                                                  fprintf(resultFile,"%s",line2);
                                                  memset(line2,0,128);
                                                  repeat =1;
                                          //if there are mutiple clients match to the same houses.align the clients' info 
                                          } else {
                                                 
                                                 sprintf(str,"%d",getClientId(list[i]));
		                                 
                                                 strcpy(repStr,str);
                                                 strcat(repStr,",");
                                                 strcat(repStr,getName(list[i]));
                                                 
                                                 fprintf(resultFile,",,,,,,,,,%s",repStr);
                                                 memset(repStr,0,128);

                                          }
                                }
                       }
                    }
            }
}







