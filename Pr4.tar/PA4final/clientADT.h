/*
 *  Author:Zheng Zhong, Zhengz42@uw,edu
 *  Version: 1.0
 *  Enviorment:Ubuntu 16.04 LTS Desktop 32-bit
 *  Option: Option 2
 *  Data: 3/4/2021
 *
 *  ClientADT header file
 *  
 *
 */ 

#include"preferenceADT.h"
#ifndef CLIENTADT_H
#define CLIENTADT_H

/*Struct client_type alias*/
typedef struct client_type *ClientType;

/*Creates a clienType data*/
ClientType createClient(int id,
		        char *name,
			char *email,
			char *phoneNum);

/*Destroies a clienType data*/
void destroyClient(ClientType client);

/*Updates references*/
void updatePreference(ClientType client,
		      int        id,
		      int        bed,
		      int        bath,
		      int        price,
		      int        neighthoodid);

/*prints client information*/
void printClient(ClientType client);

/*prints client information wtih references*/
void printClientAndReference(ClientType client);

/*ClientId getter*/
int getClientId(ClientType client);

/*Client Name getter*/
char *getName(ClientType client);

/*Client email getter*/
char *getEmail(ClientType client);

/*Client phoneNum getter*/
char *getPhoneNum(ClientType client);

/*Client preferences getter*/
Preference getPre(ClientType client);

#endif
