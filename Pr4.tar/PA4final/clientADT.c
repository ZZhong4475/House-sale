/*
 *  Author:Zheng Zhong, Zhengz42@uw,edu
 *  Version: 1.0
 *  Enviorment:Ubuntu 16.04 LTS Desktop 32-bit
 *  Option: Option 2
 *  Data: 3/4/2021
 *
 *  Defines Client Abstract Data Type
 *  
 *
 */ 

#include "clientADT.h"
#include "preferenceADT.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define SIZE 128

//clientType struct
struct client_type
{

    int   id;
    char *name;
    char *email;
    char *phoneNum;
    Preference pre;

};

//ClientADT Constructor
//pre: client's id:id, client's name:name,client's email,client's phone number:phoneNum
//pos: A clientType data is created
ClientType createClient(/*in*/ int  id,
                        /*in*/ char *name,
                        /*in*/ char *email,
                        /*in*/ char *phoneNum){

          ClientType temp = malloc(sizeof(struct client_type));
          if (temp != NULL) {
  
                   temp -> name = malloc(SIZE*sizeof(char));
                   temp -> email = malloc(SIZE*sizeof(char));
                   temp -> phoneNum = malloc(SIZE*sizeof(char));
                   temp -> id = id;
                   strcpy(temp -> name,name);
                   strcpy(temp -> email,email);
                   strcpy(temp -> phoneNum,phoneNum);
         }
 
         return temp;
}

//Updates the client preference memeber
//pre: ClientType: client, client's id:id,bedroom:bed,bathroom:bath,price:price,and neighthoodid:neighthoodid
//pos: ClientType pre memeber got updated
void updatePreference(/*in*/ ClientType client,
                      /*in*/ int        id,
                      /*in*/ int        bed,
                      /*in*/ int        bath,
                      /*in*/ int        price,
                      /*in*/ int        neighthoodid)
{
        
	client->pre = createPreference(id,bed,bath,price,neighthoodid);


}

//Destroy the clientType
//pre:ClientType:client
//post:ClientType would be destroyed
void destroyClient( /*inout*/ ClientType client) {
	
	free(client->name);
	free(client->email);
	free(client->phoneNum);
	destroyPreference(client->pre);
	free(client);
}

//Prints the client info
//pre:clientType:client
//pos:displayed client information
void printClient( /*in*/ ClientType client){
	
	printf("Id:%d,Name:%s,Email:%s,Phone Number:%s\n",
		client->id,
		client->name,
		client->email,
		client->phoneNum);


}

//Prints the client info after the preference updated
//pre:clientType:client
//pos:displayed cilent info and preferences
void printClientAndReference( /*in*/ ClientType client){
	printClient(client);
	printPreference(client->pre);
	printf("---------------------------\n");
}

//Client ID getter
//pre:clientType:client
//pos:returned the client's id
int getClientId( /*in*/ ClientType client){

	return client->id;

}

//Client name getter
//pre:clientType:client
//pos:returned the client's name
char *getName( /*in*/ ClientType client){

	return client->name;
}

//Client email getter
//pre:clientType:client
//pos:returned the client's email
char *getEmail( /*in*/ ClientType client){

	return client ->email;
}

//Client phoneNum getter
//pre:clientType:client
//pos:returned the client's phone number
char *getPhoneNum( /*in*/ ClientType client){

	return client->phoneNum;
}

//Client struct preference getter
//pre:clientType:client
//pos:returned the client's preference's data
Preference getPre( /*in*/ ClientType client){

	return client->pre;

}



